
package com.calllifo.http;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;

import javax.websocket.Session;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.neovisionaries.ws.client.WebSocket;
import com.neovisionaries.ws.client.WebSocketAdapter;
import com.neovisionaries.ws.client.WebSocketException;
import com.neovisionaries.ws.client.WebSocketFactory;

public class TradeMontor {
	private static String KEY = "";
	protected static String sessionId = "";
	public Session session;
	static CountDownLatch latch = new CountDownLatch(1);
	static ConcurrentHashMap<String, PriceListener> todaysTrades = new ConcurrentHashMap<String, PriceListener>();

	Session userSession = null;
	static WebSocket webSocket = null;

	public TradeMontor() {
		try {

			populateTodaysTrades();

			setup();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void populateTodaysTrades() {
		// TODO Auto-generated method stub
		String path = "C:\\workspace\\isaiah_60_5\\src\\main\\resources\\todaysTrades.txt";
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
			PrintWriter optionsFile = new PrintWriter(
					"C:\\workspace\\isaiah_60_5\\src\\main\\resources\\options.properties");
			PrintWriter orderFile = new PrintWriter(
					"C:\\workspace\\isaiah_60_5\\src\\main\\resources\\options.properties");
			PrintWriter cancelFile = new PrintWriter(
					"C:\\workspace\\isaiah_60_5\\src\\main\\resources\\options.properties");
			String line = br.readLine();
			System.out.println(line);
			JSONObject jobj = toJsonObject(line);

			String inputStr = "";
			inputStr = jobj.get("token") + "=" + "{\"k\":\"NFO|" + jobj.get("token") + "\",\"t\":\"t\"}";
			optionsFile.write(inputStr);
			
			inputStr = jobj.get("token") + "="
					+ "[{  \"complexty\": \"regular\",   \"discqty\": \"0\",    \"exch\": \"NFO\",    \"pCode\": \"MIS\",    \"prctyp\": \"MKT\",    \"price\": \"0.0\",    \"qty\": "
					+ jobj.get("lot_size") + ",    \"ret\": \"DAY\",    \"symbol_id\":\"" + jobj.get("token")
					+ "\", \"trading_symbol\": \"" + jobj.get("trading_symbol")
					+ "\",  \"transtype\": \"BUY\",   \"trigPrice\": \"0\",   \"orderTag\": \"order1\"       }]";
			orderFile.write(inputStr);
			
			//46461=[    {        "exchSeg": "nse_fo",        "pCode": "MIS",        "netQty": "50",        "tockenNo": "46461",        "symbol": "FINNIFTY"    }]
			inputStr = jobj.get("token") + "=" + "[    {        \"exchSeg\": \"nse_fo\",        \"pCode\": \"MIS\",        \"netQty\": \""+jobj.get("lot_size")+"\",        \"tockenNo\": \""+ jobj.get("token")+"\",        \"symbol\": \"FINNIFTY\"    }]";
			
			cancelFile.write(inputStr);
			optionsFile.close();
			orderFile.close();
			cancelFile.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void setup() throws NoSuchAlgorithmException {
		// TODO Auto-generated constructor stub
		String s1 = "1194239"
				+ "eWgVczS9Ij7aB1iyi0mRCOMvzFvbe8O1mnPKyHpAntlNPBh5jg7aSukuBOOCEU5M9iNDQJV8BrYvWW0uZM38RndrS4kcfSDlccQAZ3hezTqGB3eMNxpWpjgnxZI0TCI7"
				+ getAPIEncriptionString();
		KEY = toHexString(getSHA(s1));
		sessionId = getUserSID();
		KEY = "Bearer 1194239 " + sessionId;

		try {
			invalidateSessionID();
			websocketSessionID();
			webSocket = connectToWS();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	public void handleMessage(String message) {
		if (toJsonObject(message).containsKey("lp")) {
			(todaysTrades.get(toJsonObject(message).get("tk").toString()))
					.tradeActionAt(Double.parseDouble(toJsonObject(message).get("lp").toString()));
			System.out.println(
					"                                                                                                                            "
							+ toJsonObject(message).get("lp"));
		}

	}

	private WebSocket connectToWS() {
		try {

			WebSocket webSocket = new WebSocketFactory().createSocket("wss://ws1.aliceblueonline.com/NorenWS/")
					.addListener(new WebSocketAdapter() {
						@Override
						public void onTextMessage(WebSocket ws, String message) {
							handleMessage(message);
						}
					}).connect();

			String susertoken = "";
			try {
				susertoken = toHexString(getSHA(toHexString(getSHA(sessionId))));
				webSocket.sendText("{\r\n" + "    \"susertoken\": \"" + susertoken + "\",\r\n" + "    \"t\": \"c\",\r\n"
						+ "    \"actid\": \"1194239_API\",\r\n" + "    \"uid\": \"1194239_API\",\r\n"
						+ "    \"source\": \"API\"\r\n" + "}");
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return webSocket;
		} catch (WebSocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getUserSID() {
		HttpResponse<String> response = null;
		Unirest.setTimeouts(0, 0);
		String jsonStr = "{\r\n        \"userId\": \"1194239\",\r\n        \"userData\": \"" + KEY + "\"\r\n     } ";
		try {
			response = Unirest.post("https://ant.aliceblueonline.com/rest/AliceBlueAPIService/api/customer/getUserSID")
					.header("Content-Type", "application/json").body(jsonStr).asString();
		} catch (UnirestException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JSONParser parser = new JSONParser();
		JSONObject json = null;
		try {
			json = (JSONObject) parser.parse(response.getBody());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return (String) json.get("sessionID");
	}

	public static String getAPIEncriptionString() {
		HttpResponse<String> response = null;
		Unirest.setTimeouts(0, 0);
		try {
			response = Unirest
					.post("https://ant.aliceblueonline.com/rest/AliceBlueAPIService/api/customer/getAPIEncpkey")
					.header("Content-Type", "application/json").body("{\r\n    \"userId\":\"1194239\"\r\n}").asString();
		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONParser parser = new JSONParser();
		JSONObject json = null;
		try {
			json = (JSONObject) parser.parse(response.getBody());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return (String) json.get("encKey");
	}

	public static byte[] getSHA(String input) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}

	public static String toHexString(byte[] hash) {
		BigInteger number = new BigInteger(1, hash);
		StringBuilder hexString = new StringBuilder(number.toString(16));
		while (hexString.length() < 64) {
			hexString.insert(0, '0');
		}
		return hexString.toString();
	}

	public String invalidateSessionID() throws Exception {

		HttpResponse<String> response = null;
		Unirest.setTimeouts(0, 0);
		try {

			response = Unirest
					.post("https://ant.aliceblueonline.com/rest/AliceBlueAPIService/api/ws/invalidateSocketSess")
					.header("Authorization", KEY).asString();

		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response.getBody();

	}

	public String websocketSessionID() throws Exception {

		HttpResponse<String> response = null;
		Unirest.setTimeouts(0, 0);
		try {

			response = Unirest.post("https://ant.aliceblueonline.com/rest/AliceBlueAPIService/api/ws/createSocketSess")
					.header("Authorization", KEY).body(" {\"loginType\":\"API\"}").asString();
		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response.getBody();

	}

	public String getFunds() {

		HttpResponse<String> response = null;
		Unirest.setTimeouts(0, 0);
		try {

			response = Unirest.get("https://ant.aliceblueonline.com/rest/AliceBlueAPIService/api/limits/getRmsLimits")
					.header("Authorization", KEY).asString();

		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response.getBody();

	}

	public static JSONObject toJsonObject(String jsonStr) {
		JSONObject jsonObject = null;
		try {
			JSONParser  parser = new JSONParser();
			jsonObject = (JSONObject) parser.parse(jsonStr);
		} catch (JSONException | ParseException err) {
			err.printStackTrace();
		}
		return jsonObject;
	}

	public static void sendMessage(String stockIndex, String payLoad) {

		try {
			webSocket.sendText(payLoad);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {

		TradeMontor tradeMontor = new TradeMontor();
		try (FileInputStream input = new FileInputStream(
				"C:\\workspace\\isaiah_60_5\\src\\main\\resources\\options.properties")) {

			Properties prop = new Properties();

			// load a properties file
			prop.load(input);
			Iterator iterator = prop.keySet().iterator();
			String stockIndex = "";
			while (iterator.hasNext()) {
				stockIndex = (String) iterator.next();
				if (todaysTrades.get(stockIndex) == null) {
					todaysTrades.put(stockIndex, new PriceListener(KEY, stockIndex));
				}
				sendMessage(stockIndex, prop.getProperty(stockIndex));
			}
			// get the property value and print it out
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		latch.await();

	}

}
